var Hapi = require("hapi");
var https = require("https");

var server = new Hapi.Server();

server.connection({port:3000});

server.start(function(){
    console.log("Server running at :" , server.info.url);
});

server.route({
    method:"GET",
    path:"/get/tags/{tagname}",
    handler:function(req,reply){
        //http://api.instagram.com/v1/tags/vsco/media/recent?access_token=30806069.e1a3534.d5cf15a9aeb446e0b948b8b08afc5d22
        var options = {
            host:"api.instagram.com",
            path:"/v1/tags/" + req.params.tagname + "/media/recent?access_token=30806069.e1a3534.d5cf15a9aeb446e0b948b8b08afc5d22"
        };

        var callback = function(response){
            var str = '';
            response.on('data',function(chunk){
               str += chunk;
            });

            response.on('end',function(){
                var data = JSON.parse(str).data;

                var compiled_data = {
                    data:[],

                };

                for(var i = 0;i<data.length;++i){
                    var image = data[i].images.thumbnail.url;
                    image = image.replace("https","http");


                    compiled_data.data.push({
                        image:image,
                        id:data[i].id
                    });
                }

                reply(compiled_data);
            });
        };

        https.request(options,callback).end();

    }
});

/**
 * This returns all the photos after a particular id
 */
server.route({
    method:"GET",
    path:"/get/tags/{tagname}/{id}",
    handler:function(req,reply){
        //http://api.instagram.com/v1/tags/vsco/media/recent?access_token=30806069.e1a3534.d5cf15a9aeb446e0b948b8b08afc5d22
        var options = {
            host:"api.instagram.com",
            path:"/v1/tags/" + req.params.tagname + "/media/recent?max_tag_id=" + req.params.id +"&access_token=30806069.e1a3534.d5cf15a9aeb446e0b948b8b08afc5d22"
        };

        var callback = function(response){
            var str = '';
            response.on('data',function(chunk){
                str += chunk;
            });

            response.on('end',function(){
                var data = JSON.parse(str).data;

                var compiled_data = {
                    data:[],

                };

                for(var i = 0;i<data.length;++i){
                    var image = data[i].images.thumbnail.url;
                    image = image.replace("https","http");


                    compiled_data.data.push({
                        image:image,
                        id:data[i].id
                    });
                }

                reply(compiled_data);
            });
        };

        https.request(options,callback).end();

    }
});