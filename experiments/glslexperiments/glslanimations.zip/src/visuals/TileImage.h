//
//  TileImage.h
//  Mosaic
//
//  Created by Joseph Chow on 5/31/15.
//
//

#ifndef __Mosaic__TileImage__
#define __Mosaic__TileImage__

#include "ofMain.h"

typedef std::shared_ptr<class TileImage>TileRef;

class TileImage{
    
    //! mouse position
    ofVec2f mousePosition;
    
    //! image for this tile
    ofImage image;
    
    //! width of tile
    int width;
    
    //! height of tile
    int height;
    
    //! fbo for rendering
    ofFbo fbo;
    
    //! vbo mesh for storing vertices
    ofVboMesh mesh;
    
    //! shader for rendering
    ofShader render;
    
    //! resolution of tile
    int resolution = 5;
    
    //! indicates whether or not a image was set
    bool imageSet = false;
    
    //! Fbo used to resize things
    ofFbo resize;
    
    //! tile position
    ofVec2f position;
    
    //! width of the tile to be used in figuring out mouse position
    int tileWidth;
    
    //! height of tile to be used in figuring out mouse position.
    int tileHeight;
    
public:
    TileImage();
    
    void mousePressed(ofMouseEventArgs &mouse);
    
    void setResolution(int resolution);
    
    void draw();
    void setup();
    void setImage(ofImage image);
    
};

#endif /* defined(__Mosaic__TileImage__) */
