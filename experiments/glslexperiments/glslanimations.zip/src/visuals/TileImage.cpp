//
//  TileImage.cpp
//  Mosaic
//
//  Created by Joseph Chow on 5/31/15.
//
//

#include "TileImage.h"

using namespace std;

TileImage::TileImage():position(ofVec2f(0,0)){}

void TileImage::setup(){
    width = ofGetWindowWidth();
    height = ofGetWindowHeight();
    mesh.setUsage(GL_DYNAMIC_DRAW);
    mesh.setMode(OF_PRIMITIVE_POINTS);
    
    if(imageSet){
        const float cols = width / resolution;
        const float rows = height / resolution;
        
        tileWidth = cols;
        tileHeight = rows;
        //loop through and generate a grid
        for(int i = 0; i < width;++i){
            for(int j = 0;j < height;++j){
                int x = i;
                int y = j;
                
                mesh.addVertex(ofVec3f(x,y,0));
                mesh.addTexCoord(ofVec2f(x,y));
            }
        }
        
        //resize image
        resize.allocate(width,height);
        resize.begin();
        ofClear(0, 0, 0,1.0);
        image.draw(0,0,width,height);
        resize.end();
        
    }
  
    //set mouse position listener
    ofAddListener(ofEvents().mouseMoved,this,&TileImage::mousePressed);
    
    //set shader
    render.load("tile.vert.glsl","tile.frag.glsl");
}

void TileImage::setResolution(int resolution){
    this->resolution = resolution;
}

void TileImage::mousePressed(ofMouseEventArgs &mouse){
    mousePosition = mouse;
}

void TileImage::draw(){
    render.begin();
    //set some uniforms
    render.setUniform1f("time", ofGetElapsedTimef());
    
    //pass in mouse position as another uniform
    render.setUniform2f("mousePosition", mousePosition.x,mousePosition.y);

    //if mouse position is over the tile - pass in mouse position
    /*   if (mousePosition.x >= position.x && mousePosition.x <= position.x + tileWidth &&
     mousePosition.y >= position.y && mousePosition.y <= position.y + tileHeight) {
     render.setUniform2f("mousePosition", mousePosition.x,mousePosition.y);
     }
*/
    
    //set image as texture
    render.setUniformTexture("tileImage", resize.getTextureReference(), 0);
    
    ofPushMatrix();
    ofTranslate(position.x, position.y);
    mesh.draw();
    ofPopMatrix();
    
    render.end();
}


void TileImage::setImage(ofImage image){
    this->image = image;
    imageSet = true;
    setup();
}