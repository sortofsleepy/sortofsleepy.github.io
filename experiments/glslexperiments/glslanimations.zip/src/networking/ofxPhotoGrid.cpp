//
//  ofxPhotoGrid.cpp
//  Mosaic
//
//  Created by Joseph Chow on 5/31/15.
//
//

#include "ofxPhotoGrid.h"
using namespace std;

ofxPhotoGrid::ofxPhotoGrid(){}

void ofxPhotoGrid::setTag(std::string tag){
    this->tag = tag;
    this->url += "/" + tag;
    
    // Hack to make sure that the net sybsystem is initialized on windows.
    Poco::Net::initializeNetwork();
    
    // Register for client events.
    clientTaskQueue.registerAllEvents(this);
    
    glEnable(GL_VERTEX_PROGRAM_POINT_SIZE);

    ofAddListener(tilesLoaded,this,&ofxPhotoGrid::tilesFinished);
}
void ofxPhotoGrid::tilesFinished(bool &val){
    if(val){
        drawTiles();
    }
}
void ofxPhotoGrid::getImages(){
    ofxHTTP::GetRequest request(url,Poco::Net::HTTPMessage::HTTP_1_0);

    try {
        //get response stream
        std::istream &responseStream = client.execute(request, response, context);
        
        //convert stream to string
        std::istreambuf_iterator<char>eos;
        const string s(istreambuf_iterator<char>(responseStream),eos);
        
        //process the response
        processResponse(s);
    }catch(const Poco::Exception &exc){
        ofLogError("ofxPhotoGrid::getImages") << "Got Exception" << exc.displayText();
    }catch(...){
        ofLogError("ofxPhotoGrid::getImages")<< "Got unknown exception";
    }
    
}

void ofxPhotoGrid::drawTiles(){
    int cols = ofGetWindowWidth() / resolution;
    int rows = ofGetWindowHeight() / resolution;
    
    
    for(int i = 0;i<cols;++i){
        for(int j = 0; j < rows; ++j){
            
        }
    }
    
    for(int i = 0;i<tiles.size();++i){
        TileImage tile;
        tile.setResolution(resolution);
    }
}

void ofxPhotoGrid::processResponse(string response){
    
    Json::Reader reader;
    Json::Value root;
    
    bool parse_good = reader.parse(response,root);
    
    if(parse_good){
        for(int i = 0;i<root["data"].size();++i){
            Json::Value defaultVal = "";
            const string val = root["data"].get(i, defaultVal).toStyledString();
            images.push_back(val);
        }
        
    }else{
        ofLog()<< "Unable to process response";
    }
    
    
    // Lauch three large download tasks.
    for (int i = 0; i < images.size(); ++i)
    {
        std::string url = images.at(i);
        
        // We can use this taskId to cancel the task or keep track of its
        // progress.  In this example, we register the taskId in the
        // taskStarted() callback.
        
        Poco::UUID uuid = clientTaskQueue.get(url);
        
      //  std::cout << "Getting: " << url << std::endl;
    }
    
}


void ofxPhotoGrid::onClientBuffer(const ofx::HTTP::ClientBufferEventArgs& args)
{
    // Note: Saving to disk could / should also be done in the task's thread.
    
    // This is useful if you want to load the bytes into a GL texture.
    const ofx::IO::ByteBuffer& buffer = args.getData().getByteBuffer();
    
    try {
        ofBuffer buff;
        buff.set(buffer.getCharPtr(),buffer.size());
        ofImage img;
        img.loadImage(buff);
        
        downloadedImages.push_back(img);
        
    }catch(const Poco::Exception &exc){
        ofLogError("ofxPhotoGrid : onClientBuffer")<< exc.displayText();
    }
    
    //build tiles.
    for(int i = 0;i<downloadedImages.size();++i){
        TileImage tile;
        
        //set the image for the tile
        tile.setImage(downloadedImages.at(i)); 
        tile.setup();
        
        //add to stack
        tiles.push_back(tile);
    }
    
    bool test = true;
    ofNotifyEvent(tilesLoaded, test, this);
}