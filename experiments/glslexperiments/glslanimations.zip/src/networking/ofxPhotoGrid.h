//
//  ofxPhotoGrid.h
//  Mosaic
//
//  Created by Joseph Chow on 5/31/15.
//
//

#ifndef __Mosaic__ofxPhotoGrid__
#define __Mosaic__ofxPhotoGrid__

#include "ofMain.h"
#include "ofxHTTP.h"
#include "TileImage.h"
#include "ofxJSON.h"

//! basic wrapper around Instagram api.
//! note - you'll need to genererate a access token from time to time for certain endpoints

class ofxPhotoGrid {

    //! category of images we're looking into
    std::string tag;
    
    //! tag url
    std::string url="http://localhost:3000/get/tags";
    
    //! client for making requests
    ofx::HTTP::DefaultClient client;
    
    //! context for making requests
    ofx::HTTP::Context context;
    
    //! helps handle responses
    ofx::HTTP::BaseResponse response;
    
    //! images found
    std::vector<std::string> images;
    
    std::vector<ofImage> downloadedImages;
    
    //! tiles
    std::vector<TileImage> tiles;
    
    //! event to trigger
    ofEvent<bool> tilesLoaded;

    //resolution for each tile
    int resolution = 8;
    
public:
    ofxPhotoGrid();
    
    //! listener for when tiles are done loading
    void tilesFinished(bool &val);
    
    //! fetches images from instagram
    void getImages();
    
    //! draws the tiles
    void drawTiles();
    
    //processes the response from Instagram
    void processResponse(std::string response);

    //! set the tag to look for. Rebuilds the url when it's set
    void setTag(std::string tag);
    
    //! task events
    void onTaskQueued(const ofx::TaskQueueEventArgs& args){}
    void onTaskStarted(const ofx::TaskQueueEventArgs& args){}
    void onTaskCancelled(const ofx::TaskQueueEventArgs& args){}
    void onTaskFinished(const ofx::TaskQueueEventArgs& args){}
    void onTaskFailed(const ofx::TaskFailedEventArgs& args){}
    void onTaskProgress(const ofx::TaskProgressEventArgs& args){}
    
    //! event processing when fetching images
    void onClientBuffer(const ofx::HTTP::ClientBufferEventArgs& args);
    
    //! async task queue for loading images
    ofx::HTTP::DefaultClientTaskQueue clientTaskQueue;
    
};

#endif /* defined(__Mosaic__ofxPhotoGrid__) */
