//
//  PhotoGrid.h
//  Mosaic
//
//  Created by Joseph Chow on 6/1/15.
//
//

#ifndef __Mosaic__PhotoGrid__
#define __Mosaic__PhotoGrid__

#include "ofMain.h"
#include "ofxHTTP.h"
#include "TileImage.h"
#include "ofxJSON.h"

class PhotoGrid {
    
    //! number of tiles needed to fill the window
    int numTilesNeeded = 0;
    
    //! category of images we're looking into
    std::string tag;
    
    //! tag url
    std::string url="http://localhost:3000/get/tags";
    
    //! client for making requests
    ofx::HTTP::DefaultClient client;
    
    //! context for making requests
    ofx::HTTP::Context context;
    
    //! helps handle responses
    ofx::HTTP::BaseResponse response;
    
    //! images found
    std::vector<std::string> images;
    
    std::vector<ofImage> downloadedImages;
    
    //! tiles
    std::vector<TileImage> tiles;
    
    //! list of ids for the tiles
    std::vector<std::string> imageIds;
    
    //! event to trigger
    ofEvent<bool> tilesLoaded;
    
    //resolution for each tile
    int resolution = 8;
    
public:
    PhotoGrid();
    
    //! sets things up, figures out the number of tiles needed.
    void setup();
    
    //! fetches photos
    void getImages(string minid="");
    
    //! processes the response after polling Instagram
    void processResponse(std::string jsonstring);
    
    //! task events
    void onTaskQueued(const ofx::TaskQueueEventArgs& args){}
    void onTaskStarted(const ofx::TaskQueueEventArgs& args){}
    void onTaskCancelled(const ofx::TaskQueueEventArgs& args){}
    void onTaskFinished(const ofx::TaskQueueEventArgs& args){}
    void onTaskFailed(const ofx::TaskFailedEventArgs& args){}
    void onTaskProgress(const ofx::TaskProgressEventArgs& args){}
    
    //! event processing when fetching images
    void onClientBuffer(const ofx::HTTP::ClientBufferEventArgs& args);

    //! async task queue for loading images
    ofx::HTTP::DefaultClientTaskQueue clientTaskQueue;
};

#endif /* defined(__Mosaic__PhotoGrid__) */
